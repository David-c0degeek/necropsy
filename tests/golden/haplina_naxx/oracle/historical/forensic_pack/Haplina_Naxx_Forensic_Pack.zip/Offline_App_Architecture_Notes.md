# Offline WCL Parse Analyzer — architecture note

This is intentionally not the next implementation task yet; it records the design direction requested while the current Haplina research is completed.

## Boundary
- **Online acquisition:** WCL OAuth/API, rankings, reports, event pages, archive entitlement.
- **Offline analysis:** import existing export ZIP(s), normalize, calculate, compare, render. No WCL access required.

## Suggested local model
Use DuckDB or SQLite for persistent normalized data:
- reports(report_code, zone, start_time, archive status)
- fights(report_code, fight_id, encounter_id, boss, start/end)
- actors(report_code, actor_id, name, type, owner_id)
- combatants(report_code, fight_id, actor_id, talents/spec, gear JSON)
- events(report_code, fight_id, timestamp, type, source_id, target_id, ability_id, amount, resources/position JSON)
- leaderboard_snapshots(snapshot_time, partition, encounter_id, rank, report/fight/actor)
- derived_player_metrics(...)
- derived_pet_metrics(...)

## Analyzer modules
1. importer/validator
2. WCL schema adapter
3. spell/item dictionary
4. shot-cycle reconstruction
5. buff/cooldown interval engine
6. pet inference + uptime/death engine
7. gear consensus / encounter swaps
8. target-phase segmentation
9. parse strategy detector (e.g. Gothik non-native targets)
10. comparison/report generator

The current CSV/JSON outputs are already prototypes of those derived tables.
