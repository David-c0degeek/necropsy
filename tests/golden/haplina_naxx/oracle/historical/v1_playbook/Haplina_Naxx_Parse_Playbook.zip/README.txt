HAPLINA NAXX HUNTER PARSE PLAYBOOK

Open Haplina_Naxx_Parse_Playbook.html in any browser.
It is fully self-contained and works offline. The 'reviewed' checkboxes persist
locally in that browser.

The CSV/Markdown files are included for deeper inspection and for the future app.
